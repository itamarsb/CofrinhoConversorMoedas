package Uninter;

import java.util.ArrayList;

public class Cofrinho {
    private ArrayList<Moeda> moedas = new ArrayList<>();

    public void adicionar(Moeda m) {
        moedas.add(m);
    }

    public void remover(Moeda m) {
        moedas.remove(m);
    }

    public void listar() {
        if (moedas.isEmpty()) {
            System.out.println("Cofrinho vazio.");
            return;
        }
        for (Moeda m : moedas) {
            m.info();
        }
    }

    public double calcularTotalConvertido() {
        double total = 0;
        for (Moeda m : moedas) {
            total += m.converterParaReal();
        }
        return total;
    }
}
