package Uninter;

public abstract class Moeda {
    double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    public abstract void info();
    public abstract double converterParaReal();

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Moeda outra) {
            return this.valor == outra.valor && this.getClass() == outra.getClass();
        }
        return false;
    }
}
