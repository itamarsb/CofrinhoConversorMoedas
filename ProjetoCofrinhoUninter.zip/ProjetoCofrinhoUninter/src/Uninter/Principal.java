package Uninter;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofre = new Cofrinho();

        int opcao;
        do {
            System.out.println("\nMENU COFRINHO:");
            System.out.println("1 - Adicionar Moeda");
            System.out.println("2 - Remover Moeda");
            System.out.println("3 - Listar Moedas");
            System.out.println("4 - Calcular Total Convertido para Real");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 -> {
                    System.out.println("1 - Real | 2 - Dólar | 3 - Euro");
                    int tipo = scanner.nextInt();
                    System.out.print("Informe o valor: ");
                    double valor = scanner.nextDouble();
                    switch (tipo) {
                        case 1 -> cofre.adicionar(new Real(valor));
                        case 2 -> cofre.adicionar(new Dolar(valor));
                        case 3 -> cofre.adicionar(new Euro(valor));
                        default -> System.out.println("Tipo inválido.");
                    }
                }
                case 2 -> {
                    System.out.println("1 - Real | 2 - Dólar | 3 - Euro");
                    int tipo = scanner.nextInt();
                    System.out.print("Informe o valor da moeda a remover: ");
                    double valor = scanner.nextDouble();
                    Moeda m = switch (tipo) {
                        case 1 -> new Real(valor);
                        case 2 -> new Dolar(valor);
                        case 3 -> new Euro(valor);
                        default -> null;
                    };
                    if (m != null) cofre.remover(m);
                }
                case 3 -> cofre.listar();
                case 4 -> System.out.printf("Total convertido: R$ %.2f\n", cofre.calcularTotalConvertido());
                case 0 -> System.out.println("Encerrando programa...");
                default -> System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

        scanner.close();
    }
}
